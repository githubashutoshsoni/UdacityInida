package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
        return null;
    }
}
